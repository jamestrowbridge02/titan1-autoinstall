// server.js - simplified for bundle (full implementation recommended from earlier content)
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const WebSocket = require('ws');

const PORT = process.env.PORT || 8080;
const DB_FILE = process.env.DATABASE_FILE || './titan_core.db';

function openDb(file){ return new Promise((resolve,reject)=>{ const db=new sqlite3.Database(file, (e)=>e?reject(e):resolve(db)); }); }

(async ()=> {
  const app = express();
  app.use(bodyParser.json());
  app.get('/', (req,res)=> res.sendFile(path.join(__dirname,'index.html')));
  app.get('/healthz', (req,res)=> res.json({ok:true,ts:new Date().toISOString()}));
  const server = app.listen(PORT, ()=> console.log('Listening',PORT));
  const wss = new WebSocket.Server({ server });
  wss.on('connection', ws => { ws.send(JSON.stringify({ type:'hello', payload:{ ts: new Date().toISOString() } })); });
})();
