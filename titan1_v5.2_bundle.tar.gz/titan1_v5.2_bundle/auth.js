// auth module placeholder
module.exports = {};
