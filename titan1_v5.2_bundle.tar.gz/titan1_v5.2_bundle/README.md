Titan-1 v5.2 — Runbook

Overview
Titan-1 v5.2 is a production-ready Node.js algorithmic trading engine. It includes:
- Web UI with WebSocket updates and charts
- JWT-based auth + rotating API keys + refresh tokens
- Strategy sandboxing via Worker Threads (web UI uploads)
- Real OHLCV via ccxt (public polling)
- Prometheus metrics + Grafana dashboard JSON
- Backups to AWS S3 & Google Cloud Storage
- systemd service provided

Quick start (bare-metal)
1. Create a `titan` user and place files under /opt/titan.
2. Copy .env.example -> .env and set secrets.
3. sudo chown -R titan:titan /opt/titan
4. npm ci
5. Setup NGINX and Certbot (see nginx/titan1.conf).
6. sudo systemctl daemon-reload; sudo systemctl enable titan1.service; sudo systemctl start titan1.service
7. Visit https://yourdomain after certs are issued.

Security
- Keep .env private (chmod 600).
- Do NOT expose admin endpoints to the public without firewall rules.
- Use strong JWT keys and rotate frequently.

Backups
- Configure either S3 or GCS with credentials and bucket in .env.
- backup.js runs periodic backups when server runs.

Testing & CI
- Jest tests included; run `npm test`.
- CI action included for GitHub Actions.

Support
- Test in PAPER mode extensively before switching to LIVE.
