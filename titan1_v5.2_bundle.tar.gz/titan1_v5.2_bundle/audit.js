// audit placeholder
module.exports = { auditAppend: ()=>{} };
