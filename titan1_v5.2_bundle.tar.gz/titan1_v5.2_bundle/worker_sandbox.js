// worker sandbox placeholder
module.exports = { saveStrategyFile: ()=>'', runStrategyFile: async ()=>({ok:false, error:'not implemented'}) };
