// strategy engine placeholder
module.exports = { loadBuiltinStrategies: ()=>[], listUploadedStrategies: ()=>[], uploadStrategy: ()=>'', runUploadedStrategy: async ()=>({ok:false}) };
