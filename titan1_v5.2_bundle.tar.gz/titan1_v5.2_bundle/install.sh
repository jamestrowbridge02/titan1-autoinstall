#!/usr/bin/env bash
set -euo pipefail
TITAN_DIR=/opt/titan
TITAN_USER=titan

if ! id -u ${TITAN_USER} >/dev/null 2>&1; then
  sudo useradd -r -s /usr/sbin/nologin ${TITAN_USER} || true
fi

sudo mkdir -p ${TITAN_DIR}
sudo chown -R ${TITAN_USER}:${TITAN_USER} ${TITAN_DIR}

curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get update
sudo apt-get install -y nodejs nginx certbot python3-certbot-nginx

cd ${TITAN_DIR}
sudo -u ${TITAN_USER} npm ci --production

sudo cp titan1.service /etc/systemd/system/titan1.service
sudo systemctl daemon-reload
sudo systemctl enable titan1.service

echo "Installer finished. Edit .env in ${TITAN_DIR} and create nginx config then run certbot."
