#cloud-config
runcmd:
 - echo "cloud-init placeholder"
