module.exports={name:'BreakoutBuiltIn', async getSignal(){ return null; }};
