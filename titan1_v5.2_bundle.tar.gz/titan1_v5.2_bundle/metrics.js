// metrics placeholder
module.exports = { register: { contentType:'text/plain' }, setEquity:()=>{}, setTotalPnl:()=>{}, incTrades:()=>{}, setHardDeck:()=>{} };
